#pragma once

class UVec4
{
public:
  float x;
  float y;
  float z;
  float w;
};

class UVec3
{
public:
  float x;
  float y;
  float z;
};

class UVec2
{
public:
  float x;
  float y;
};
